import { Component, ViewContainerRef, ViewChild } from '@angular/core';
import { FieldWrapper } from 'ng-formly';
@Component({
  selector: 'formly-wrapper-horizontal',
  template: `
    <div class="row">
      <label attr.for="{{key}}" class="col-sm-4 form-control-label">{{templateOptions.label}}</label>
      <div class="col-sm-8">
        <template #fieldComponent></template>
      </div>
    </div>
  `,
})
export class FormlyWrapperHorizontalLabel extends FieldWrapper {
  @ViewChild('fieldComponent', {read: ViewContainerRef}) fieldComponent: ViewContainerRef;
}
