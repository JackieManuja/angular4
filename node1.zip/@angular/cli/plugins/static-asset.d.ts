export declare class StaticAssetPlugin {
    private name;
    private contents;
    constructor(name: string, contents: string);
    apply(compiler: any): void;
}
