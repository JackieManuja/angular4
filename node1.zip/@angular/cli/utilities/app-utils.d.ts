export declare function getAppFromConfig(nameOrIndex?: String): any;
