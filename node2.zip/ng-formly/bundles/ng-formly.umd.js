(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("@angular/core"), require("@angular/forms"), require("@angular/common"), require("rxjs/Subject"), require("rxjs/operator/debounceTime"), require("rxjs/operator/map"));
	else if(typeof define === 'function' && define.amd)
		define(["@angular/core", "@angular/forms", "@angular/common", "rxjs/Subject", "rxjs/operator/debounceTime", "rxjs/operator/map"], factory);
	else if(typeof exports === 'object')
		exports["ng-formly"] = factory(require("@angular/core"), require("@angular/forms"), require("@angular/common"), require("rxjs/Subject"), require("rxjs/operator/debounceTime"), require("rxjs/operator/map"));
	else
		root["ng-formly"] = factory(root["@angular/core"], root["@angular/forms"], root["@angular/common"], root["rxjs/Subject"], root["rxjs/operator/debounceTime"], root["rxjs/operator/map"]);
})(this, function(__WEBPACK_EXTERNAL_MODULE_1__, __WEBPACK_EXTERNAL_MODULE_3__, __WEBPACK_EXTERNAL_MODULE_18__, __WEBPACK_EXTERNAL_MODULE_39__, __WEBPACK_EXTERNAL_MODULE_40__, __WEBPACK_EXTERNAL_MODULE_41__) {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 22);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (immutable) */ __webpack_exports__["__extends"] = __extends;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (immutable) */ __webpack_exports__["__rest"] = __rest;
/* harmony export (immutable) */ __webpack_exports__["__decorate"] = __decorate;
/* harmony export (immutable) */ __webpack_exports__["__param"] = __param;
/* harmony export (immutable) */ __webpack_exports__["__metadata"] = __metadata;
/* harmony export (immutable) */ __webpack_exports__["__awaiter"] = __awaiter;
/* harmony export (immutable) */ __webpack_exports__["__generator"] = __generator;
/* harmony export (immutable) */ __webpack_exports__["__exportStar"] = __exportStar;
/* harmony export (immutable) */ __webpack_exports__["__values"] = __values;
/* harmony export (immutable) */ __webpack_exports__["__read"] = __read;
/* harmony export (immutable) */ __webpack_exports__["__spread"] = __spread;
/* harmony export (immutable) */ __webpack_exports__["__await"] = __await;
/* harmony export (immutable) */ __webpack_exports__["__asyncGenerator"] = __asyncGenerator;
/* harmony export (immutable) */ __webpack_exports__["__asyncDelegator"] = __asyncDelegator;
/* harmony export (immutable) */ __webpack_exports__["__asyncValues"] = __asyncValues;
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = Object.setPrototypeOf ||
    ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
    function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);  }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { if (o[n]) i[n] = function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; }; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator];
    return m ? m.call(o) : typeof __values === "function" ? __values(o) : o[Symbol.iterator]();
}

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_1__;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var formly_form_1 = __webpack_require__(11);
exports.FormlyForm = formly_form_1.FormlyForm;
var formly_field_1 = __webpack_require__(10);
exports.FormlyField = formly_field_1.FormlyField;
var formly_attributes_1 = __webpack_require__(9);
exports.FormlyAttributes = formly_attributes_1.FormlyAttributes;
var formly_config_1 = __webpack_require__(5);
exports.FormlyConfig = formly_config_1.FormlyConfig;
var formly_form_builder_1 = __webpack_require__(7);
exports.FormlyFormBuilder = formly_form_builder_1.FormlyFormBuilder;
var formly_validation_messages_1 = __webpack_require__(13);
exports.FormlyValidationMessages = formly_validation_messages_1.FormlyValidationMessages;
var formly_event_emitter_1 = __webpack_require__(6);
exports.FormlyPubSub = formly_event_emitter_1.FormlyPubSub;
exports.FormlyEventEmitter = formly_event_emitter_1.FormlyEventEmitter;
var field_1 = __webpack_require__(8);
exports.Field = field_1.Field;
var field_type_1 = __webpack_require__(14);
exports.FieldType = field_type_1.FieldType;
var field_wrapper_1 = __webpack_require__(21);
exports.FieldWrapper = field_wrapper_1.FieldWrapper;
var core_module_1 = __webpack_require__(20);
exports.FormlyModule = core_module_1.FormlyModule;


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_3__;

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function getFieldId(formId, options, index) {
    if (options.id)
        return options.id;
    var type = options.type;
    if (!type && options.template)
        type = 'template';
    return [formId, type, options.key, index].join('_');
}
exports.getFieldId = getFieldId;
function getKeyPath(field) {
    if (field['_formlyKeyPath'] !== undefined) {
        return field['_formlyKeyPath'];
    }
    var keyPath = [];
    if (field.key) {
        var pathElements = typeof field.key === 'string' ? field.key.split('.') : field.key;
        for (var _i = 0, pathElements_1 = pathElements; _i < pathElements_1.length; _i++) {
            var pathElement = pathElements_1[_i];
            if (typeof pathElement === 'string') {
                pathElement = pathElement.replace(/\[(\w+)\]/g, '.$1');
                keyPath = keyPath.concat(pathElement.split('.'));
            }
            else {
                keyPath.push(pathElement);
            }
        }
        for (var i = 0; i < keyPath.length; i++) {
            var pathElement = keyPath[i];
            if (typeof pathElement === 'string' && stringIsInteger(pathElement)) {
                keyPath[i] = parseInt(pathElement);
            }
        }
    }
    field['_formlyKeyPath'] = keyPath;
    return keyPath;
}
exports.getKeyPath = getKeyPath;
function stringIsInteger(str) {
    return !isNullOrUndefined(str) && /^\d+$/.test(str);
}
function getFieldModel(model, field, constructEmptyObjects) {
    var keyPath = getKeyPath(field);
    var value = model;
    for (var i = 0; i < keyPath.length; i++) {
        var path = keyPath[i];
        var pathValue = value[path];
        if (isNullOrUndefined(pathValue) && constructEmptyObjects) {
            if (i < keyPath.length - 1) {
                value[path] = typeof keyPath[i + 1] === 'number' ? [] : {};
            }
            else if (field.fieldGroup) {
                value[path] = {};
            }
            else if (field.fieldArray) {
                value[path] = [];
            }
        }
        value = value[path];
        if (!value) {
            break;
        }
    }
    return value;
}
exports.getFieldModel = getFieldModel;
function assignModelValue(model, path, value) {
    if (typeof path === 'string') {
        path = getKeyPath({ key: path });
    }
    if (path.length > 1) {
        var e = path.shift();
        if (!model[e]) {
            model[e] = isNaN(path[0]) ? {} : [];
        }
        assignModelValue(model[e], path, value);
    }
    else {
        model[path[0]] = value;
    }
}
exports.assignModelValue = assignModelValue;
function getValueForKey(model, path) {
    if (typeof path === 'string') {
        path = getKeyPath({ key: path });
    }
    if (path.length > 1) {
        var e = path.shift();
        if (!model[e]) {
            model[e] = isNaN(path[0]) ? {} : [];
        }
        return getValueForKey(model[e], path);
    }
    else {
        return model[path[0]];
    }
}
exports.getValueForKey = getValueForKey;
function getKey(controlKey, actualKey) {
    return actualKey ? actualKey + '.' + controlKey : controlKey;
}
exports.getKey = getKey;
function reverseDeepMerge(dest, source) {
    if (source === void 0) { source = undefined; }
    var args = Array.prototype.slice.call(arguments);
    if (!args[1]) {
        return dest;
    }
    args.forEach(function (src, index) {
        if (!index) {
            return;
        }
        for (var srcArg in src) {
            if (isNullOrUndefined(dest[srcArg]) || isBlankString(dest[srcArg])) {
                if (isFunction(src[srcArg])) {
                    dest[srcArg] = src[srcArg];
                }
                else {
                    dest[srcArg] = clone(src[srcArg]);
                }
            }
            else if (objAndSameType(dest[srcArg], src[srcArg])) {
                reverseDeepMerge(dest[srcArg], src[srcArg]);
            }
        }
    });
    return dest;
}
exports.reverseDeepMerge = reverseDeepMerge;
function isNullOrUndefined(value) {
    return value === undefined || value === null;
}
exports.isNullOrUndefined = isNullOrUndefined;
function isUndefined(value) {
    return value === undefined;
}
exports.isUndefined = isUndefined;
function isBlankString(value) {
    return value === '';
}
exports.isBlankString = isBlankString;
function isFunction(value) {
    return typeof (value) === 'function';
}
exports.isFunction = isFunction;
function objAndSameType(obj1, obj2) {
    return isObject(obj1) && isObject(obj2) &&
        Object.getPrototypeOf(obj1) === Object.getPrototypeOf(obj2);
}
exports.objAndSameType = objAndSameType;
function isObject(x) {
    return x != null && typeof x === 'object';
}
exports.isObject = isObject;
function clone(value) {
    if (!isObject(value)) {
        return value;
    }
    return Array.isArray(value) ? value.slice(0) : Object.assign({}, value);
}
exports.clone = clone;
function evalStringExpression(expression, argNames) {
    try {
        return Function.bind.apply(Function, [void 0].concat(argNames.concat("return " + expression + ";")))();
    }
    catch (error) {
        console.error(error);
    }
}
exports.evalStringExpression = evalStringExpression;
function evalExpressionValueSetter(expression, argNames) {
    try {
        return Function.bind
            .apply(Function, [void 0].concat(argNames.concat(expression + " = expressionValue;")))();
    }
    catch (error) {
        console.error(error);
    }
}
exports.evalExpressionValueSetter = evalExpressionValueSetter;
function evalExpression(expression, thisArg, argVal) {
    if (expression instanceof Function) {
        return expression.apply(thisArg, argVal);
    }
    else {
        return expression ? true : false;
    }
}
exports.evalExpression = evalExpression;


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var formly_group_1 = __webpack_require__(12);
var utils_1 = __webpack_require__(4);
exports.FORMLY_CONFIG_TOKEN = new core_1.OpaqueToken('FORMLY_CONFIG_TOKEN');
var FormlyConfig = (function () {
    function FormlyConfig(configs) {
        if (configs === void 0) { configs = []; }
        var _this = this;
        this.types = {
            'formly-group': {
                name: 'formly-group',
                component: formly_group_1.FormlyGroup,
            },
        };
        this.validators = {};
        this.wrappers = {};
        this.templateManipulators = {
            preWrapper: [],
            postWrapper: [],
        };
        this.extras = {
            fieldTransform: undefined,
            showError: function (field) {
                return field.formControl.touched && !field.formControl.valid;
            },
        };
        configs.map(function (config) { return _this.addConfig(config); });
    }
    FormlyConfig.prototype.addConfig = function (config) {
        var _this = this;
        if (config.types) {
            config.types.map(function (type) { return _this.setType(type); });
        }
        if (config.validators) {
            config.validators.map(function (validator) { return _this.setValidator(validator); });
        }
        if (config.wrappers) {
            config.wrappers.map(function (wrapper) { return _this.setWrapper(wrapper); });
        }
        if (config.manipulators) {
            config.manipulators.map(function (manipulator) { return _this.setManipulator(manipulator); });
        }
        if (config.extras) {
            this.extras = tslib_1.__assign({}, this.extras, config.extras);
        }
    };
    FormlyConfig.prototype.setType = function (options) {
        var _this = this;
        if (Array.isArray(options)) {
            options.map(function (option) {
                _this.setType(option);
            });
        }
        else {
            if (!this.types[options.name]) {
                this.types[options.name] = {};
            }
            this.types[options.name].component = options.component;
            this.types[options.name].name = options.name;
            this.types[options.name].extends = options.extends;
            this.types[options.name].defaultOptions = options.defaultOptions;
            if (options.wrappers) {
                options.wrappers.map(function (wrapper) {
                    _this.setTypeWrapper(options.name, wrapper);
                });
            }
        }
    };
    FormlyConfig.prototype.getType = function (name) {
        if (!this.types[name]) {
            throw new Error("[Formly Error] There is no type by the name of \"" + name + "\"");
        }
        if (!this.types[name].component && this.types[name].extends) {
            this.types[name].component = this.getType(this.types[name].extends).component;
        }
        return this.types[name];
    };
    FormlyConfig.prototype.getMergedField = function (field) {
        var _this = this;
        if (field === void 0) { field = {}; }
        var name = field.type;
        if (!this.types[name]) {
            throw new Error("[Formly Error] There is no type by the name of \"" + name + "\"");
        }
        if (!this.types[name].component && this.types[name].extends) {
            this.types[name].component = this.getType(this.types[name].extends).component;
        }
        if (this.types[name].defaultOptions) {
            utils_1.reverseDeepMerge(field, this.types[name].defaultOptions);
        }
        var extendDefaults = this.types[name].extends && this.getType(this.types[name].extends).defaultOptions;
        if (extendDefaults) {
            utils_1.reverseDeepMerge(field, extendDefaults);
        }
        if (field && field.optionsTypes) {
            field.optionsTypes.map(function (option) {
                var defaultOptions = _this.getType(option).defaultOptions;
                if (defaultOptions) {
                    utils_1.reverseDeepMerge(field, defaultOptions);
                }
            });
        }
        utils_1.reverseDeepMerge(field, this.types[name]);
    };
    FormlyConfig.prototype.setWrapper = function (options) {
        var _this = this;
        this.wrappers[options.name] = options;
        if (options.types) {
            options.types.map(function (type) {
                _this.setTypeWrapper(type, options.name);
            });
        }
    };
    FormlyConfig.prototype.getWrapper = function (name) {
        if (!this.wrappers[name]) {
            throw new Error("[Formly Error] There is no wrapper by the name of \"" + name + "\"");
        }
        return this.wrappers[name];
    };
    FormlyConfig.prototype.setTypeWrapper = function (type, name) {
        if (!this.types[type]) {
            this.types[type] = {};
        }
        if (!this.types[type].wrappers) {
            this.types[type].wrappers = [];
        }
        this.types[type].wrappers.push(name);
    };
    FormlyConfig.prototype.setValidator = function (options) {
        this.validators[options.name] = options;
    };
    FormlyConfig.prototype.getValidator = function (name) {
        if (!this.validators[name]) {
            throw new Error("[Formly Error] There is no validator by the name of \"" + name + "\"");
        }
        return this.validators[name];
    };
    FormlyConfig.prototype.setManipulator = function (manipulator) {
        new manipulator.class()[manipulator.method](this);
    };
    return FormlyConfig;
}());
FormlyConfig = tslib_1.__decorate([
    core_1.Injectable(),
    tslib_1.__param(0, core_1.Inject(exports.FORMLY_CONFIG_TOKEN)),
    tslib_1.__metadata("design:paramtypes", [Array])
], FormlyConfig);
exports.FormlyConfig = FormlyConfig;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var Subject_1 = __webpack_require__(39);
var FormlyValueChangeEvent = (function () {
    function FormlyValueChangeEvent(key, value) {
        this.key = key;
        this.value = value;
    }
    return FormlyValueChangeEvent;
}());
exports.FormlyValueChangeEvent = FormlyValueChangeEvent;
var FormlyEventEmitter = (function (_super) {
    tslib_1.__extends(FormlyEventEmitter, _super);
    function FormlyEventEmitter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FormlyEventEmitter.prototype.emit = function (value) {
        _super.prototype.next.call(this, value);
    };
    return FormlyEventEmitter;
}(Subject_1.Subject));
exports.FormlyEventEmitter = FormlyEventEmitter;
var FormlyPubSub = (function () {
    function FormlyPubSub() {
        this.emitters = {};
    }
    FormlyPubSub.prototype.setEmitter = function (key, emitter) {
        this.emitters[key] = emitter;
    };
    FormlyPubSub.prototype.getEmitter = function (key) {
        return this.emitters[key];
    };
    FormlyPubSub.prototype.removeEmitter = function (key) {
        delete this.emitters[key];
    };
    return FormlyPubSub;
}());
exports.FormlyPubSub = FormlyPubSub;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var formly_config_1 = __webpack_require__(5);
var utils_1 = __webpack_require__(4);
var utils_2 = __webpack_require__(4);
var FormlyFormBuilder = (function () {
    function FormlyFormBuilder(formlyConfig) {
        this.formlyConfig = formlyConfig;
        this.validationOpts = ['required', 'pattern', 'minLength', 'maxLength', 'min', 'max'];
        this.formId = 0;
    }
    FormlyFormBuilder.prototype.buildForm = function (form, fields, model, options) {
        if (fields === void 0) { fields = []; }
        this.formId++;
        options = options || {};
        if (!options.showError) {
            options.showError = this.formlyConfig.extras.showError;
        }
        var fieldTransforms = (options && options.fieldTransform) || this.formlyConfig.extras.fieldTransform;
        if (!Array.isArray(fieldTransforms)) {
            fieldTransforms = [fieldTransforms];
        }
        fieldTransforms.forEach(function (fieldTransform) {
            if (fieldTransform) {
                fields = fieldTransform(fields, model, form, options);
                if (!fields) {
                    throw new Error('fieldTransform must return an array of fields');
                }
            }
        });
        this.registerFormControls(form, fields, model, options);
    };
    FormlyFormBuilder.prototype.registerFormControls = function (form, fields, model, options) {
        var _this = this;
        fields.map(function (field, index) {
            field.id = utils_1.getFieldId("formly_" + _this.formId, field, index);
            _this.initFieldTemplateOptions(field);
            _this.initFieldExpression(field, model, options);
            _this.initFieldValidation(field);
            _this.initFieldAsyncValidation(field);
            if (field.key && field.type) {
                _this.formlyConfig.getMergedField(field);
                var path = field.key;
                if (typeof path === 'string') {
                    if (!utils_2.isUndefined(field.defaultValue)) {
                        _this.defaultPath = path;
                    }
                    path = utils_2.getKeyPath({ key: field.key });
                }
                if (path.length > 1) {
                    var rootPath = path.shift();
                    var nestedForm = (form.get(rootPath.toString()) ? form.get(rootPath.toString()) : new forms_1.FormGroup({}));
                    if (!form.get(rootPath.toString())) {
                        form.addControl(rootPath, nestedForm);
                    }
                    if (!model[rootPath]) {
                        model[rootPath] = isNaN(path[0]) ? {} : [];
                    }
                    var originalKey = field.key;
                    field.key = path;
                    _this.buildForm(nestedForm, [field], model[rootPath], options);
                    field.key = originalKey;
                }
                else {
                    if (!utils_2.isUndefined(field.defaultValue) && utils_2.isUndefined(model[path[0]])) {
                        var modelPath = utils_2.getKeyPath({ key: _this.defaultPath });
                        modelPath = modelPath.pop();
                        utils_1.assignModelValue(model, modelPath, field.defaultValue);
                        _this.defaultPath = undefined;
                    }
                    _this.addFormControl(form, field, model[path[0]]);
                }
            }
            if (field.fieldGroup) {
                if (field.key) {
                    if (!model.hasOwnProperty(field.key)) {
                        model[field.key] = {};
                    }
                    var nestedForm = form.get(field.key), nestedModel = model[field.key] || {};
                    if (!nestedForm) {
                        nestedForm = new forms_1.FormGroup({}, field.validators ? field.validators.validation : undefined, field.asyncValidators ? field.asyncValidators.validation : undefined);
                        _this.addControl(form, field.key, nestedForm, field);
                    }
                    _this.buildForm(nestedForm, field.fieldGroup, nestedModel, options);
                }
                else {
                    _this.buildForm(form, field.fieldGroup, model, options);
                }
            }
            if (field.fieldArray && field.key) {
                if (!(form.get(field.key) instanceof forms_1.FormArray)) {
                    var arrayForm = new forms_1.FormArray([], field.validators ? field.validators.validation : undefined, field.asyncValidators ? field.asyncValidators.validation : undefined);
                    _this.addControl(form, field.key, arrayForm, field);
                }
            }
        });
    };
    FormlyFormBuilder.prototype.initFieldExpression = function (field, model, options) {
        options.formState = options.formState || {};
        if (field.expressionProperties) {
            for (var key in field.expressionProperties) {
                if (typeof field.expressionProperties[key] === 'string') {
                    field.expressionProperties[key] = {
                        expression: utils_1.evalStringExpression(field.expressionProperties[key], ['model', 'formState']),
                        expressionValueSetter: utils_1.evalExpressionValueSetter(key, ['expressionValue', 'model', 'templateOptions', 'validation']),
                    };
                }
                var expressionValue = utils_1.evalExpression(field.expressionProperties[key].expression, { field: field }, [model, options.formState]);
                field.expressionProperties[key].expressionValue = expressionValue;
                utils_1.evalExpression(field.expressionProperties[key].expressionValueSetter, { field: field }, [expressionValue, model, field.templateOptions || {}, field.validation]);
            }
        }
        if (typeof field.hideExpression === 'string') {
            field.hideExpression = utils_1.evalStringExpression(field.hideExpression, ['model', 'formState']);
            field.hide = utils_1.evalExpression(field.hideExpression, { field: field }, [model, options.formState]);
        }
    };
    FormlyFormBuilder.prototype.initFieldTemplateOptions = function (field) {
        if (field.key && field.type) {
            field.templateOptions = Object.assign({
                label: '',
                placeholder: '',
                focus: false,
            }, field.templateOptions);
        }
    };
    FormlyFormBuilder.prototype.initFieldAsyncValidation = function (field) {
        var _this = this;
        var validators = [];
        if (field.asyncValidators) {
            var _loop_1 = function (validatorName) {
                if (validatorName !== 'validation') {
                    validators.push(function (control) {
                        var validator = field.asyncValidators[validatorName];
                        if (utils_1.isObject(validator)) {
                            validator = validator.expression;
                        }
                        return new Promise(function (resolve) {
                            return validator(control).then(function (result) {
                                resolve(result ? null : (_a = {}, _a[validatorName] = true, _a));
                                var _a;
                            });
                        });
                    });
                }
            };
            for (var validatorName in field.asyncValidators) {
                _loop_1(validatorName);
            }
        }
        if (field.asyncValidators && Array.isArray(field.asyncValidators.validation)) {
            field.asyncValidators.validation.map(function (validate) {
                if (typeof validate === 'string') {
                    validators.push(_this.formlyConfig.getValidator(validate).validation);
                }
                else {
                    validators.push(validate);
                }
            });
        }
        if (validators.length) {
            if (field.asyncValidators && !Array.isArray(field.asyncValidators.validation)) {
                field.asyncValidators.validation = forms_1.Validators.composeAsync([field.asyncValidators.validation].concat(validators));
            }
            else {
                field.asyncValidators = {
                    validation: forms_1.Validators.composeAsync(validators),
                };
            }
        }
    };
    FormlyFormBuilder.prototype.initFieldValidation = function (field) {
        var _this = this;
        var validators = [];
        this.validationOpts.filter(function (opt) { return field.templateOptions && field.templateOptions[opt]; }).map(function (opt) {
            validators.push(_this.getValidation(opt, field.templateOptions[opt]));
        });
        if (field.validators) {
            var _loop_2 = function (validatorName) {
                if (validatorName !== 'validation') {
                    validators.push(function (control) {
                        var validator = field.validators[validatorName];
                        if (utils_1.isObject(validator)) {
                            validator = validator.expression;
                        }
                        return validator(control) ? null : (_a = {}, _a[validatorName] = true, _a);
                        var _a;
                    });
                }
            };
            for (var validatorName in field.validators) {
                _loop_2(validatorName);
            }
        }
        if (field.validators && Array.isArray(field.validators.validation)) {
            field.validators.validation.map(function (validate) {
                if (typeof validate === 'string') {
                    validators.push(_this.formlyConfig.getValidator(validate).validation);
                }
                else {
                    validators.push(validate);
                }
            });
        }
        if (validators.length) {
            if (field.validators && !Array.isArray(field.validators.validation)) {
                field.validators.validation = forms_1.Validators.compose([field.validators.validation].concat(validators));
            }
            else {
                field.validators = {
                    validation: forms_1.Validators.compose(validators),
                };
            }
        }
    };
    FormlyFormBuilder.prototype.addFormControl = function (form, field, model) {
        var name = typeof field.key === 'string' ? field.key : field.key[0], formControl;
        if (field.formControl instanceof forms_1.AbstractControl) {
            formControl = field.formControl;
        }
        else if (field.component && field.component.createControl) {
            formControl = field.component.createControl(model, field);
        }
        else {
            formControl = new forms_1.FormControl({ value: model, disabled: field.templateOptions.disabled }, field.validators ? field.validators.validation : undefined, field.asyncValidators ? field.asyncValidators.validation : undefined);
        }
        this.addControl(form, name, formControl, field);
        if (field.validation && field.validation.show) {
            form.get(field.key).markAsTouched();
        }
    };
    FormlyFormBuilder.prototype.getValidation = function (opt, value) {
        var _this = this;
        switch (opt) {
            case this.validationOpts[0]:
                return forms_1.Validators[opt];
            case this.validationOpts[1]:
            case this.validationOpts[2]:
            case this.validationOpts[3]:
                return forms_1.Validators[opt](value);
            case this.validationOpts[4]:
            case this.validationOpts[5]:
                return function (changes) {
                    if (_this.checkMinMax(opt, changes.value, value)) {
                        return null;
                    }
                    else {
                        return _a = {}, _a[opt] = true, _a;
                    }
                    var _a;
                };
        }
    };
    FormlyFormBuilder.prototype.checkMinMax = function (opt, changes, value) {
        if (changes == null || changes === '') {
            return true;
        }
        if (opt === this.validationOpts[4]) {
            return parseInt(changes) >= value;
        }
        else {
            return parseInt(changes) <= value;
        }
    };
    FormlyFormBuilder.prototype.addControl = function (form, key, formControl, field) {
        field.formControl = formControl;
        if (field.hide) {
            return;
        }
        if (formControl instanceof forms_1.FormArray) {
            form.setControl(key, formControl);
        }
        else {
            form.addControl(key, formControl);
        }
    };
    return FormlyFormBuilder;
}());
FormlyFormBuilder = tslib_1.__decorate([
    core_1.Injectable(),
    tslib_1.__metadata("design:paramtypes", [formly_config_1.FormlyConfig])
], FormlyFormBuilder);
exports.FormlyFormBuilder = FormlyFormBuilder;


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var Field = (function () {
    function Field() {
    }
    Object.defineProperty(Field.prototype, "key", {
        get: function () { return this.field.key; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "formControl", {
        get: function () { return this.field.formControl || this.form.get(this.key); },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "templateOptions", {
        get: function () {
            console.warn(this.constructor['name'] + ": 'templateOptions' is deprecated. Use 'to' instead.");
            return this.to;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "to", {
        get: function () { return this.field.templateOptions; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "valid", {
        get: function () { return this.options.showError(this); },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "id", {
        get: function () { return this.field.id; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Field.prototype, "formState", {
        get: function () { return this.options.formState || {}; },
        enumerable: true,
        configurable: true
    });
    return Field;
}());
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", forms_1.FormGroup)
], Field.prototype, "form", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], Field.prototype, "field", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], Field.prototype, "model", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], Field.prototype, "options", void 0);
exports.Field = Field;


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var FormlyAttributes = (function () {
    function FormlyAttributes(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.attributes = ['id', 'name', 'placeholder', 'tabindex', 'step', 'aria-describedby'];
        this.statements = ['change', 'keydown', 'keyup', 'keypress', 'click', 'focus', 'blur'];
    }
    FormlyAttributes.prototype.onFocus = function () {
        this.field.focus = true;
    };
    FormlyAttributes.prototype.onBlur = function () {
        this.field.focus = false;
    };
    FormlyAttributes.prototype.ngOnChanges = function (changes) {
        var _this = this;
        if (changes['field']) {
            var fieldChanges_1 = changes['field'];
            this.attributes
                .filter(function (attr) { return _this.canApplyRender(fieldChanges_1, attr); })
                .map(function (attr) { return _this.renderer.setElementAttribute(_this.elementRef.nativeElement, attr, _this.getPropValue(_this.field, attr)); });
            this.statements
                .filter(function (statement) { return _this.canApplyRender(fieldChanges_1, statement); })
                .map(function (statement) { return _this.renderer.listen(_this.elementRef.nativeElement, statement, _this.getStatementValue(statement)); });
            if ((fieldChanges_1.previousValue || {}).focus !== (fieldChanges_1.currentValue || {}).focus) {
                this.renderer.invokeElementMethod(this.elementRef.nativeElement, this.field.focus ? 'focus' : 'blur', []);
            }
        }
    };
    FormlyAttributes.prototype.getPropValue = function (field, prop) {
        field = field || {};
        if (field.id && prop === 'aria-describedby') {
            return field.id + '-message';
        }
        if (field.templateOptions && field.templateOptions[prop]) {
            return field.templateOptions[prop];
        }
        return field[prop];
    };
    FormlyAttributes.prototype.getStatementValue = function (statement) {
        var _this = this;
        var fn = this.field.templateOptions[statement];
        return function () { return fn(_this.field, _this.formControl); };
    };
    FormlyAttributes.prototype.canApplyRender = function (fieldChange, prop) {
        var currentValue = this.getPropValue(this.field, prop), previousValue = this.getPropValue(fieldChange.previousValue, prop);
        if (previousValue !== currentValue) {
            if (this.statements.indexOf(prop) !== -1) {
                return typeof currentValue === 'function';
            }
            return true;
        }
        return false;
    };
    return FormlyAttributes;
}());
tslib_1.__decorate([
    core_1.Input('formlyAttributes'),
    tslib_1.__metadata("design:type", Object)
], FormlyAttributes.prototype, "field", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyAttributes.prototype, "formControl", void 0);
tslib_1.__decorate([
    core_1.HostListener('focus'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], FormlyAttributes.prototype, "onFocus", null);
tslib_1.__decorate([
    core_1.HostListener('blur'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], FormlyAttributes.prototype, "onBlur", null);
FormlyAttributes = tslib_1.__decorate([
    core_1.Directive({
        selector: '[formlyAttributes]',
    }),
    tslib_1.__metadata("design:paramtypes", [core_1.Renderer,
        core_1.ElementRef])
], FormlyAttributes);
exports.FormlyAttributes = FormlyAttributes;


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var formly_event_emitter_1 = __webpack_require__(6);
var formly_config_1 = __webpack_require__(5);
var utils_1 = __webpack_require__(4);
var debounceTime_1 = __webpack_require__(40);
var map_1 = __webpack_require__(41);
var FormlyField = (function () {
    function FormlyField(elementRef, formlyPubSub, renderer, formlyConfig, componentFactoryResolver) {
        this.elementRef = elementRef;
        this.formlyPubSub = formlyPubSub;
        this.renderer = renderer;
        this.formlyConfig = formlyConfig;
        this.componentFactoryResolver = componentFactoryResolver;
        this.options = {};
        this.modelChange = new core_1.EventEmitter();
        this.componentRefs = [];
        this._subscriptions = [];
    }
    FormlyField.prototype.ngDoCheck = function () {
        this.checkExpressionChange();
        this.checkVisibilityChange();
    };
    FormlyField.prototype.ngOnInit = function () {
        this.createFieldComponents();
        if (this.field.hide === true) {
            this.toggleHide(true);
        }
    };
    FormlyField.prototype.ngOnDestroy = function () {
        this.componentRefs.map(function (componentRef) { return componentRef.destroy(); });
        this._subscriptions.map(function (subscriber) { return subscriber.unsubscribe(); });
        this._subscriptions = this.componentRefs = [];
        if (this.field && this.field.key) {
            this.formlyPubSub.removeEmitter(this.field.key);
        }
    };
    FormlyField.prototype.changeModel = function (event) {
        this.modelChange.emit(event);
    };
    FormlyField.prototype.createFieldComponents = function () {
        var _this = this;
        if (this.field && !this.field.template && !this.field.fieldGroup && !this.field.fieldArray) {
            var debounce = 0;
            if (this.field.modelOptions && this.field.modelOptions.debounce && this.field.modelOptions.debounce.default) {
                debounce = this.field.modelOptions.debounce.default;
            }
            var fieldComponentRef = this.createFieldComponent();
            if (this.field.key) {
                var valueChanges_1 = fieldComponentRef.instance.formControl.valueChanges;
                if (debounce > 0) {
                    valueChanges_1 = debounceTime_1.debounceTime.call(valueChanges_1, debounce);
                }
                if (this.field.parsers && this.field.parsers.length > 0) {
                    this.field.parsers.map(function (parserFn) {
                        valueChanges_1 = map_1.map.call(valueChanges_1, parserFn);
                    });
                }
                this._subscriptions.push(valueChanges_1.subscribe(function (event) { return _this
                    .changeModel(new formly_event_emitter_1.FormlyValueChangeEvent(_this.field.key, event)); }));
            }
            var update = new formly_event_emitter_1.FormlyEventEmitter();
            this._subscriptions.push(update.subscribe(function (option) {
                _this.field.templateOptions[option.key] = option.value;
            }));
            this.formlyPubSub.setEmitter(this.field.key, update);
        }
        else if (this.field.fieldGroup || this.field.fieldArray) {
            this.createFieldComponent();
        }
    };
    FormlyField.prototype.createFieldComponent = function () {
        var _this = this;
        if (this.field.fieldGroup) {
            this.field.type = this.field.type || 'formly-group';
        }
        var type = this.formlyConfig.getType(this.field.type);
        var fieldComponent = this.fieldComponent;
        var fieldManipulators = this.getManipulators(this.field.templateOptions);
        var preWrappers = this.runManipulators(fieldManipulators.preWrapper, this.field);
        var postWrappers = this.runManipulators(fieldManipulators.postWrapper, this.field);
        if (!type.wrappers)
            type.wrappers = [];
        if (this.field.wrapper) {
            console.warn(this.field.key + ": wrapper is deprecated. Use 'wrappers' instead.");
            this.field.wrappers = Array.isArray(this.field.wrapper) ? this.field.wrapper : [this.field.wrapper];
        }
        if (!this.field.wrappers)
            this.field.wrappers = [];
        var wrappers = preWrappers.concat(this.field.wrappers, postWrappers);
        wrappers.map(function (wrapperName) {
            var wrapperRef = _this.createComponent(fieldComponent, _this.formlyConfig.getWrapper(wrapperName).component);
            fieldComponent = wrapperRef.instance.fieldComponent;
        });
        return this.createComponent(fieldComponent, type.component);
    };
    FormlyField.prototype.createComponent = function (fieldComponent, component) {
        var componentFactory = this.componentFactoryResolver.resolveComponentFactory(component);
        var ref = fieldComponent.createComponent(componentFactory);
        Object.assign(ref.instance, {
            model: this.model,
            form: this.form,
            field: this.field,
            options: this.options,
        });
        this.componentRefs.push(ref);
        return ref;
    };
    FormlyField.prototype.psEmit = function (fieldKey, eventKey, value) {
        if (this.formlyPubSub && this.formlyPubSub.getEmitter(fieldKey) && this.formlyPubSub.getEmitter(fieldKey).emit) {
            this.formlyPubSub.getEmitter(fieldKey).emit(new formly_event_emitter_1.FormlyValueChangeEvent(eventKey, value));
        }
    };
    FormlyField.prototype.getManipulators = function (options) {
        var preWrapper = [];
        var postWrapper = [];
        if (options && options.templateManipulators) {
            addManipulators(options.templateManipulators);
        }
        addManipulators(this.formlyConfig.templateManipulators);
        return { preWrapper: preWrapper, postWrapper: postWrapper };
        function addManipulators(manipulators) {
            var _a = (manipulators || {}), _b = _a.preWrapper, pre = _b === void 0 ? [] : _b, _c = _a.postWrapper, post = _c === void 0 ? [] : _c;
            preWrapper = preWrapper.concat(pre);
            postWrapper = postWrapper.concat(post);
        }
    };
    FormlyField.prototype.runManipulators = function (manipulators, field) {
        var wrappers = [];
        if (manipulators) {
            manipulators.map(function (manipulator) {
                if (manipulator(field)) {
                    wrappers.push(manipulator(field));
                }
            });
            return wrappers;
        }
    };
    FormlyField.prototype.checkVisibilityChange = function () {
        if (this.field && this.field.hideExpression) {
            var hideExpressionResult = !!utils_1.evalExpression(this.field.hideExpression, this, [this.model, this.options.formState]);
            if (hideExpressionResult !== this.field.hide) {
                this.toggleHide(hideExpressionResult);
            }
        }
    };
    FormlyField.prototype.checkExpressionChange = function () {
        if (this.field && this.field.expressionProperties) {
            var expressionProperties = this.field.expressionProperties;
            for (var key in expressionProperties) {
                var expressionValue = utils_1.evalExpression(expressionProperties[key].expression, this, [this.model, this.options.formState]);
                if (expressionProperties[key].expressionValue !== expressionValue) {
                    expressionProperties[key].expressionValue = expressionValue;
                    utils_1.evalExpression(expressionProperties[key].expressionValueSetter, this, [expressionValue, this.model, this.field.templateOptions, this.field.validation]);
                }
            }
            var formControl = this.field.formControl;
            if (formControl) {
                if (formControl.status === 'DISABLED' && !this.field.templateOptions.disabled) {
                    formControl.enable();
                }
                if (formControl.status !== 'DISABLED' && this.field.templateOptions.disabled) {
                    formControl.disable();
                }
                if (!formControl.dirty && formControl.invalid && this.field.validation && !this.field.validation.show) {
                    formControl.markAsUntouched();
                }
                if (!formControl.dirty && formControl.invalid && this.field.validation && this.field.validation.show) {
                    formControl.markAsTouched();
                }
            }
        }
    };
    FormlyField.prototype.toggleHide = function (value) {
        var _this = this;
        this.field.hide = value;
        if (this.field.formControl) {
            if (value === true && this.form.get(this.field.key)) {
                setTimeout(function () { return _this.removeFieldControl(); });
            }
            else if (value === false && !this.form.get(this.field.key)) {
                setTimeout(function () { return _this.addFieldControl(); });
            }
        }
        this.renderer.setElementStyle(this.elementRef.nativeElement, 'display', value ? 'none' : '');
        if (this.field.fieldGroup) {
            for (var i = 0; i < this.field.fieldGroup.length; i++) {
                this.psEmit(this.field.fieldGroup[i].key, 'hidden', value);
            }
        }
        else {
            this.psEmit(this.field.key, 'hidden', value);
        }
    };
    Object.defineProperty(FormlyField.prototype, "fieldKey", {
        get: function () {
            return this.field.key.split('.').pop();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FormlyField.prototype, "fieldParentFormControl", {
        get: function () {
            var paths = this.field.key.split('.');
            paths.pop();
            return (paths.length > 0 ? this.form.get(paths) : this.form);
        },
        enumerable: true,
        configurable: true
    });
    FormlyField.prototype.addFieldControl = function () {
        var parent = this.fieldParentFormControl;
        if (parent instanceof forms_1.FormArray) {
            parent.push(this.field.formControl);
        }
        else if (parent instanceof forms_1.FormGroup) {
            parent.addControl(this.fieldKey, this.field.formControl);
        }
    };
    FormlyField.prototype.removeFieldControl = function () {
        var parent = this.fieldParentFormControl;
        if (parent instanceof forms_1.FormArray) {
            parent.removeAt(this.fieldKey);
        }
        else if (parent instanceof forms_1.FormGroup) {
            parent.removeControl(this.fieldKey);
        }
    };
    return FormlyField;
}());
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyField.prototype, "model", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", forms_1.FormGroup)
], FormlyField.prototype, "form", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyField.prototype, "field", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyField.prototype, "options", void 0);
tslib_1.__decorate([
    core_1.Output(),
    tslib_1.__metadata("design:type", core_1.EventEmitter)
], FormlyField.prototype, "modelChange", void 0);
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyField.prototype, "fieldComponent", void 0);
FormlyField = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field',
        template: "\n    <ng-container #fieldComponent></ng-container>\n    <div *ngIf=\"field.template && !field.fieldGroup\" [innerHtml]=\"field.template\"></div>\n  ",
    }),
    tslib_1.__metadata("design:paramtypes", [core_1.ElementRef,
        formly_event_emitter_1.FormlyPubSub,
        core_1.Renderer,
        formly_config_1.FormlyConfig,
        core_1.ComponentFactoryResolver])
], FormlyField);
exports.FormlyField = FormlyField;


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var formly_form_builder_1 = __webpack_require__(7);
var utils_1 = __webpack_require__(4);
var FormlyForm = (function () {
    function FormlyForm(formlyBuilder) {
        this.formlyBuilder = formlyBuilder;
        this.model = {};
        this.form = new forms_1.FormGroup({});
        this.fields = [];
        this.buildForm = true;
    }
    FormlyForm.prototype.ngOnChanges = function (changes) {
        if (changes['fields']) {
            this.model = this.model || {};
            this.form = this.form || (new forms_1.FormGroup({}));
            this.setOptions();
            if (this.buildForm !== false) {
                this.formlyBuilder.buildForm(this.form, this.fields, this.model, this.options);
            }
            this.updateInitialValue();
        }
        else if (changes['model'] && this.fields && this.fields.length > 0) {
            this.form.patchValue(this.model);
        }
    };
    FormlyForm.prototype.fieldModel = function (field) {
        if (field.key && (field.fieldGroup || field.fieldArray)) {
            return utils_1.getFieldModel(this.model, field, true);
        }
        return this.model;
    };
    FormlyForm.prototype.changeModel = function (event) {
        utils_1.assignModelValue(this.model, event.key, event.value);
    };
    FormlyForm.prototype.setOptions = function () {
        this.options = this.options || {};
        if (!this.options.resetModel) {
            this.options.resetModel = this.resetModel.bind(this);
        }
        if (!this.options.updateInitialValue) {
            this.options.updateInitialValue = this.updateInitialValue.bind(this);
        }
    };
    FormlyForm.prototype.resetModel = function (model) {
        model = utils_1.isNullOrUndefined(model) ? this.initialModel : model;
        this.form.patchValue(model);
        this.resetFormGroup(model, this.form);
        this.resetFormModel(model, this.model);
    };
    FormlyForm.prototype.resetFormModel = function (model, formModel, path) {
        if (!utils_1.isObject(model) && !Array.isArray(model)) {
            return;
        }
        for (var key in formModel) {
            if (!(key in model) || utils_1.isNullOrUndefined(model[key])) {
                if (!this.form.get((path || []).concat(key))) {
                    delete formModel[key];
                }
            }
        }
        for (var key in model) {
            if (!utils_1.isNullOrUndefined(model[key])) {
                if (key in formModel) {
                    this.resetFormModel(model[key], formModel[key], (path || []).concat(key));
                }
                else {
                    formModel[key] = model[key];
                }
            }
        }
    };
    FormlyForm.prototype.resetFormGroup = function (model, form, actualKey) {
        for (var controlKey in form.controls) {
            var key = utils_1.getKey(controlKey, actualKey);
            if (form.controls[controlKey] instanceof forms_1.FormGroup) {
                this.resetFormGroup(model, form.controls[controlKey], key);
            }
            if (form.controls[controlKey] instanceof forms_1.FormArray) {
                this.resetFormArray(model, form.controls[controlKey], key);
            }
            if (form.controls[controlKey] instanceof forms_1.FormControl) {
                form.controls[controlKey].setValue(utils_1.getValueForKey(model, key));
            }
        }
    };
    FormlyForm.prototype.resetFormArray = function (model, formArray, key) {
        var newValue = utils_1.getValueForKey(model, key);
        for (var i = formArray.length - 1; i >= 0; i--) {
            if (formArray.at(i) instanceof forms_1.FormGroup) {
                if (newValue && !utils_1.isNullOrUndefined(newValue[i])) {
                    this.resetFormGroup(newValue[i], formArray.at(i));
                }
                else {
                    formArray.removeAt(i);
                    var value = utils_1.getValueForKey(this.model, key);
                    if (Array.isArray(value)) {
                        value.splice(i, 1);
                    }
                }
            }
        }
        if (Array.isArray(newValue) && formArray.length < newValue.length) {
            var remaining = newValue.length - formArray.length;
            var initialLength = formArray.length;
            for (var i = 0; i < remaining; i++) {
                var pos = initialLength + i;
                utils_1.getValueForKey(this.model, key).push(newValue[pos]);
                formArray.push(new forms_1.FormGroup({}));
            }
        }
    };
    FormlyForm.prototype.updateInitialValue = function () {
        var obj = utils_1.reverseDeepMerge(this.form.value, this.model);
        this.initialModel = JSON.parse(JSON.stringify(obj));
    };
    return FormlyForm;
}());
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyForm.prototype, "model", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", forms_1.FormGroup)
], FormlyForm.prototype, "form", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Array)
], FormlyForm.prototype, "fields", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyForm.prototype, "options", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Boolean)
], FormlyForm.prototype, "buildForm", void 0);
FormlyForm = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-form',
        template: "\n    <formly-field *ngFor=\"let field of fields\"\n      [model]=\"fieldModel(field)\" [form]=\"form\"\n      [field]=\"field\" (modelChange)=\"changeModel($event)\"\n      [ngClass]=\"field.className\"\n      [options]=\"options\">\n    </formly-field>\n    <ng-content></ng-content>\n  ",
    }),
    tslib_1.__metadata("design:paramtypes", [formly_form_builder_1.FormlyFormBuilder])
], FormlyForm);
exports.FormlyForm = FormlyForm;


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var field_type_1 = __webpack_require__(14);
var utils_1 = __webpack_require__(4);
var FormlyGroup = (function (_super) {
    tslib_1.__extends(FormlyGroup, _super);
    function FormlyGroup() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FormlyGroup.prototype, "newOptions", {
        get: function () {
            return utils_1.clone(this.options);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FormlyGroup.prototype, "formlyGroup", {
        get: function () {
            if (this.field.formControl) {
                return this.field.formControl;
            }
            else {
                return this.form;
            }
        },
        enumerable: true,
        configurable: true
    });
    return FormlyGroup;
}(field_type_1.FieldType));
FormlyGroup = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-group',
        template: "\n    <formly-form [fields]=\"field.fieldGroup\" [model]=\"model\" [form]=\"formlyGroup\" [options]=\"newOptions\" [ngClass]=\"field.fieldGroupClassName\" [buildForm]=\"false\"></formly-form>\n  ",
    })
], FormlyGroup);
exports.FormlyGroup = FormlyGroup;


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var formly_config_1 = __webpack_require__(5);
var FormlyValidationMessages = (function () {
    function FormlyValidationMessages(configs) {
        if (configs === void 0) { configs = []; }
        var _this = this;
        this.messages = {};
        configs.map(function (config) {
            if (config.validationMessages) {
                config.validationMessages.map(function (validation) { return _this.addStringMessage(validation.name, validation.message); });
            }
        });
    }
    FormlyValidationMessages.prototype.addStringMessage = function (validator, message) {
        this.messages[validator] = message;
    };
    FormlyValidationMessages.prototype.getMessages = function () {
        return this.messages;
    };
    FormlyValidationMessages.prototype.getValidatorErrorMessage = function (prop) {
        return this.messages[prop];
    };
    return FormlyValidationMessages;
}());
FormlyValidationMessages = tslib_1.__decorate([
    core_1.Injectable(),
    tslib_1.__param(0, core_1.Inject(formly_config_1.FORMLY_CONFIG_TOKEN)),
    tslib_1.__metadata("design:paramtypes", [Object])
], FormlyValidationMessages);
exports.FormlyValidationMessages = FormlyValidationMessages;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var field_1 = __webpack_require__(8);
var FieldType = (function (_super) {
    tslib_1.__extends(FieldType, _super);
    function FieldType() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FieldType.prototype.ngOnInit = function () {
        this.lifeCycleHooks('onInit');
    };
    FieldType.prototype.ngOnChanges = function (changes) {
        this.lifeCycleHooks('onChanges');
    };
    FieldType.prototype.ngDoCheck = function () {
        this.lifeCycleHooks('doCheck');
    };
    FieldType.prototype.ngAfterContentInit = function () {
        this.lifeCycleHooks('afterContentInit');
    };
    FieldType.prototype.ngAfterContentChecked = function () {
        this.lifeCycleHooks('afterContentChecked');
    };
    FieldType.prototype.ngAfterViewInit = function () {
        this.lifeCycleHooks('afterViewInit');
    };
    FieldType.prototype.ngAfterViewChecked = function () {
        this.lifeCycleHooks('afterViewChecked');
    };
    FieldType.prototype.ngOnDestroy = function () {
        this.lifeCycleHooks('onDestroy');
    };
    Object.defineProperty(FieldType.prototype, "lifecycle", {
        get: function () {
            return this.field.lifecycle;
        },
        enumerable: true,
        configurable: true
    });
    FieldType.prototype.lifeCycleHooks = function (type) {
        if (this.lifecycle && this.lifecycle[type]) {
            this.lifecycle[type].bind(this)(this.form, this.field, this.model, this.options);
        }
    };
    return FieldType;
}(field_1.Field));
exports.FieldType = FieldType;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var core_2 = __webpack_require__(2);
var FormlyValidationMessage = (function () {
    function FormlyValidationMessage(formlyMessages) {
        this.formlyMessages = formlyMessages;
    }
    Object.defineProperty(FormlyValidationMessage.prototype, "errorMessage", {
        get: function () {
            var _this = this;
            var _loop_1 = function (error) {
                if (this_1.fieldForm.errors.hasOwnProperty(error)) {
                    var message_1 = this_1.formlyMessages.getValidatorErrorMessage(error);
                    if (this_1.field.validation && this_1.field.validation.messages && this_1.field.validation.messages[error]) {
                        message_1 = this_1.field.validation.messages[error];
                    }
                    ['validators', 'asyncValidators'].map(function (validators) {
                        if (_this.field[validators] && _this.field[validators][error] && _this.field[validators][error].message) {
                            message_1 = _this.field.validators[error].message;
                        }
                    });
                    if (typeof message_1 === 'function') {
                        return { value: message_1(this_1.fieldForm.errors[error], this_1.field) };
                    }
                    return { value: message_1 };
                }
            };
            var this_1 = this;
            for (var error in this.fieldForm.errors) {
                var state_1 = _loop_1(error);
                if (typeof state_1 === "object")
                    return state_1.value;
            }
        },
        enumerable: true,
        configurable: true
    });
    return FormlyValidationMessage;
}());
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", forms_1.FormControl)
], FormlyValidationMessage.prototype, "fieldForm", void 0);
tslib_1.__decorate([
    core_1.Input(),
    tslib_1.__metadata("design:type", Object)
], FormlyValidationMessage.prototype, "field", void 0);
FormlyValidationMessage = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-validation-message',
        template: "{{errorMessage}}",
    }),
    tslib_1.__metadata("design:paramtypes", [core_2.FormlyValidationMessages])
], FormlyValidationMessage);
exports.FormlyValidationMessage = FormlyValidationMessage;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var checkbox_1 = __webpack_require__(26);
exports.FormlyFieldCheckbox = checkbox_1.FormlyFieldCheckbox;
var multicheckbox_1 = __webpack_require__(28);
exports.FormlyFieldMultiCheckbox = multicheckbox_1.FormlyFieldMultiCheckbox;
var input_1 = __webpack_require__(27);
exports.FormlyFieldInput = input_1.FormlyFieldInput;
var radio_1 = __webpack_require__(29);
exports.FormlyFieldRadio = radio_1.FormlyFieldRadio;
var textarea_1 = __webpack_require__(31);
exports.FormlyFieldTextArea = textarea_1.FormlyFieldTextArea;
var select_1 = __webpack_require__(30);
exports.FormlyFieldSelect = select_1.FormlyFieldSelect;


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var fieldset_1 = __webpack_require__(36);
exports.FormlyWrapperFieldset = fieldset_1.FormlyWrapperFieldset;
var label_1 = __webpack_require__(37);
exports.FormlyWrapperLabel = label_1.FormlyWrapperLabel;
var description_1 = __webpack_require__(35);
exports.FormlyWrapperDescription = description_1.FormlyWrapperDescription;
var message_validation_1 = __webpack_require__(38);
exports.FormlyWrapperValidationMessages = message_validation_1.FormlyWrapperValidationMessages;


/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_18__;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(16));
__export(__webpack_require__(17));
var formly_validation_message_1 = __webpack_require__(15);
exports.FormlyValidationMessage = formly_validation_message_1.FormlyValidationMessage;
var ui_bootstrap_module_1 = __webpack_require__(33);
exports.FormlyBootstrapModule = ui_bootstrap_module_1.FormlyBootstrapModule;


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var common_1 = __webpack_require__(18);
var forms_1 = __webpack_require__(3);
var formly_form_1 = __webpack_require__(11);
var formly_field_1 = __webpack_require__(10);
var formly_attributes_1 = __webpack_require__(9);
var formly_config_1 = __webpack_require__(5);
var formly_form_builder_1 = __webpack_require__(7);
var formly_validation_messages_1 = __webpack_require__(13);
var formly_event_emitter_1 = __webpack_require__(6);
var formly_group_1 = __webpack_require__(12);
var FORMLY_DIRECTIVES = [formly_form_1.FormlyForm, formly_field_1.FormlyField, formly_attributes_1.FormlyAttributes, formly_group_1.FormlyGroup];
var FormlyModule = FormlyModule_1 = (function () {
    function FormlyModule() {
    }
    FormlyModule.forRoot = function (config) {
        if (config === void 0) { config = {}; }
        return {
            ngModule: FormlyModule_1,
            providers: [
                formly_form_builder_1.FormlyFormBuilder,
                formly_config_1.FormlyConfig,
                formly_event_emitter_1.FormlyPubSub,
                formly_validation_messages_1.FormlyValidationMessages,
                { provide: formly_config_1.FORMLY_CONFIG_TOKEN, useValue: config, multi: true },
                { provide: core_1.ANALYZE_FOR_ENTRY_COMPONENTS, useValue: config, multi: true },
            ],
        };
    };
    FormlyModule.forChild = function (config) {
        if (config === void 0) { config = {}; }
        return {
            ngModule: FormlyModule_1,
            providers: [
                { provide: formly_config_1.FORMLY_CONFIG_TOKEN, useValue: config, multi: true },
                { provide: core_1.ANALYZE_FOR_ENTRY_COMPONENTS, useValue: config, multi: true },
            ],
        };
    };
    return FormlyModule;
}());
FormlyModule = FormlyModule_1 = tslib_1.__decorate([
    core_1.NgModule({
        declarations: FORMLY_DIRECTIVES,
        entryComponents: [formly_group_1.FormlyGroup],
        exports: FORMLY_DIRECTIVES,
        imports: [
            common_1.CommonModule,
            forms_1.ReactiveFormsModule,
        ],
    })
], FormlyModule);
exports.FormlyModule = FormlyModule;
var FormlyModule_1;


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var field_1 = __webpack_require__(8);
var FieldWrapper = (function (_super) {
    tslib_1.__extends(FieldWrapper, _super);
    function FieldWrapper() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FieldWrapper;
}(field_1.Field));
exports.FieldWrapper = FieldWrapper;


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(2));
__export(__webpack_require__(19));


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var TemplateAddons = (function () {
    function TemplateAddons() {
    }
    TemplateAddons.prototype.run = function (fc) {
        fc.templateManipulators.postWrapper.push(function (field) {
            if (field && field.templateOptions && (field.templateOptions.addonLeft || field.templateOptions.addonRight)) {
                return 'addons';
            }
        });
    };
    return TemplateAddons;
}());
exports.TemplateAddons = TemplateAddons;


/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var TemplateDescription = (function () {
    function TemplateDescription() {
    }
    TemplateDescription.prototype.run = function (fc) {
        fc.templateManipulators.postWrapper.push(function (field) {
            if (field && field.templateOptions && field.templateOptions.description) {
                return 'description';
            }
        });
    };
    return TemplateDescription;
}());
exports.TemplateDescription = TemplateDescription;


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var TemplateValidation = (function () {
    function TemplateValidation() {
    }
    TemplateValidation.prototype.run = function (fc) {
        fc.templateManipulators.postWrapper.push(function (field) {
            if (field && field.validators) {
                return 'validation-message';
            }
        });
    };
    return TemplateValidation;
}());
exports.TemplateValidation = TemplateValidation;


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var core_2 = __webpack_require__(2);
var FormlyFieldCheckbox = (function (_super) {
    tslib_1.__extends(FormlyFieldCheckbox, _super);
    function FormlyFieldCheckbox() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FormlyFieldCheckbox.createControl = function (model, field) {
        return new forms_1.FormControl({ value: model ? 'on' : undefined, disabled: field.templateOptions.disabled }, field.validators ? field.validators.validation : undefined, field.asyncValidators ? field.asyncValidators.validation : undefined);
    };
    return FormlyFieldCheckbox;
}(core_2.FieldType));
FormlyFieldCheckbox = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-checkbox',
        template: "\n    <label class=\"custom-control custom-checkbox\">\n      <input type=\"checkbox\" [formControl]=\"formControl\"\n        *ngIf=\"!to.hidden\" value=\"on\"\n        [formlyAttributes]=\"field\" class=\"custom-control-input\">\n        {{to.label}}\n        <span class=\"custom-control-indicator\"></span>\n    </label>\n  ",
    })
], FormlyFieldCheckbox);
exports.FormlyFieldCheckbox = FormlyFieldCheckbox;


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyFieldInput = (function (_super) {
    tslib_1.__extends(FormlyFieldInput, _super);
    function FormlyFieldInput() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FormlyFieldInput.prototype, "type", {
        get: function () {
            return this.to.type || 'text';
        },
        enumerable: true,
        configurable: true
    });
    return FormlyFieldInput;
}(core_2.FieldType));
FormlyFieldInput = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-input',
        template: "\n    <input [type]=\"type\" [formControl]=\"formControl\" class=\"form-control\"\n      [formlyAttributes]=\"field\" [ngClass]=\"{'form-control-danger': valid}\">\n    ",
    })
], FormlyFieldInput);
exports.FormlyFieldInput = FormlyFieldInput;


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var forms_1 = __webpack_require__(3);
var core_2 = __webpack_require__(2);
var FormlyFieldMultiCheckbox = (function (_super) {
    tslib_1.__extends(FormlyFieldMultiCheckbox, _super);
    function FormlyFieldMultiCheckbox() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FormlyFieldMultiCheckbox.createControl = function (model, field) {
        var controlGroupConfig = field.templateOptions.options.reduce(function (previous, option) {
            previous[option.key] = new forms_1.FormControl(model ? model[option.key] : undefined);
            return previous;
        }, {});
        return new forms_1.FormGroup(controlGroupConfig, field.validators ? field.validators.validation : undefined, field.asyncValidators ? field.asyncValidators.validation : undefined);
    };
    return FormlyFieldMultiCheckbox;
}(core_2.FieldType));
FormlyFieldMultiCheckbox = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-multicheckbox',
        template: "\n    <div *ngFor=\"let option of to.options\" class=\"checkbox\">\n        <label class=\"custom-control custom-checkbox\">\n            <input type=\"checkbox\" [value]=\"option.value\" [formControl]=\"formControl.get(option.key)\"\n            [formlyAttributes]=\"field\" class=\"custom-control-input\">\n            {{option.value}}\n            <span class=\"custom-control-indicator\"></span>\n        </label>\n    </div>\n  ",
    })
], FormlyFieldMultiCheckbox);
exports.FormlyFieldMultiCheckbox = FormlyFieldMultiCheckbox;


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyFieldRadio = (function (_super) {
    tslib_1.__extends(FormlyFieldRadio, _super);
    function FormlyFieldRadio() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormlyFieldRadio;
}(core_2.FieldType));
FormlyFieldRadio = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-radio',
        template: "\n    <div [formGroup]=\"form\">\n      <div *ngFor=\"let option of to.options\" class=\"radio\">\n        <label class=\"custom-control custom-radio\">\n          <input [name]=\"id\" type=\"radio\" [value]=\"option.key\" [formControl]=\"formControl\"\n          [formlyAttributes]=\"field\" class=\"custom-control-input\">\n          {{option.value}}\n          <span class=\"custom-control-indicator\"></span>\n        </label>\n      </div>\n    </div>\n  ",
    })
], FormlyFieldRadio);
exports.FormlyFieldRadio = FormlyFieldRadio;


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var SelectOption = (function () {
    function SelectOption(label, value, children) {
        this.label = label;
        this.value = value;
        this.group = children;
    }
    return SelectOption;
}());
exports.SelectOption = SelectOption;
var FormlyFieldSelect = (function (_super) {
    tslib_1.__extends(FormlyFieldSelect, _super);
    function FormlyFieldSelect() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FormlyFieldSelect.prototype, "labelProp", {
        get: function () { return this.to['labelProp'] || 'label'; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FormlyFieldSelect.prototype, "valueProp", {
        get: function () { return this.to['valueProp'] || 'value'; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FormlyFieldSelect.prototype, "groupProp", {
        get: function () { return this.to['groupProp'] || 'group'; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FormlyFieldSelect.prototype, "selectOptions", {
        get: function () {
            var _this = this;
            var options = [];
            this.to.options.map(function (option) {
                if (!option[_this.groupProp]) {
                    options.push(option);
                }
                else {
                    var filteredOption = options.filter(function (filteredOption) {
                        return filteredOption.label === option[_this.groupProp];
                    });
                    if (filteredOption[0]) {
                        filteredOption[0].group.push({
                            label: option[_this.labelProp],
                            value: option[_this.valueProp],
                        });
                    }
                    else {
                        options.push({
                            label: option[_this.groupProp],
                            group: [{ value: option[_this.valueProp], label: option[_this.labelProp] }],
                        });
                    }
                }
            });
            return options;
        },
        enumerable: true,
        configurable: true
    });
    return FormlyFieldSelect;
}(core_2.FieldType));
FormlyFieldSelect = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-select',
        template: "\n    <select [formControl]=\"formControl\" class=\"form-control\" [formlyAttributes]=\"field\">\n      <option value=\"\" *ngIf=\"to.placeholder\">{{to.placeholder}}</option>\n      <ng-container *ngFor=\"let item of selectOptions\">\n       <optgroup *ngIf=\"item.group\" label=\"{{item.label}}\">\n         <option *ngFor=\"let child of item.group\" [value]=\"child.value\" [disabled]=\"item.disabled\">\n           {{child.label}}\n         </option>\n       </optgroup>\n       <option *ngIf=\"!item.group\" [value]=\"item.value\" [disabled]=\"item.disabled\">{{item.label}}</option>\n      </ng-container>\n    </select>\n  ",
    })
], FormlyFieldSelect);
exports.FormlyFieldSelect = FormlyFieldSelect;


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyFieldTextArea = (function (_super) {
    tslib_1.__extends(FormlyFieldTextArea, _super);
    function FormlyFieldTextArea() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormlyFieldTextArea;
}(core_2.FieldType));
FormlyFieldTextArea = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-field-textarea',
        template: "\n    <textarea [name]=\"key\" [formControl]=\"formControl\" [cols]=\"to.cols\"\n      [rows]=\"to.rows\" class=\"form-control\"\n      [formlyAttributes]=\"field\">\n    </textarea>\n  ",
    })
], FormlyFieldTextArea);
exports.FormlyFieldTextArea = FormlyFieldTextArea;


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var addons_1 = __webpack_require__(34);
var description_1 = __webpack_require__(24);
var validation_1 = __webpack_require__(25);
var addon_1 = __webpack_require__(23);
var types_1 = __webpack_require__(16);
var wrappers_1 = __webpack_require__(17);
exports.FIELD_TYPE_COMPONENTS = [
    types_1.FormlyFieldInput,
    types_1.FormlyFieldCheckbox,
    types_1.FormlyFieldRadio,
    types_1.FormlyFieldSelect,
    types_1.FormlyFieldTextArea,
    types_1.FormlyFieldMultiCheckbox,
    wrappers_1.FormlyWrapperLabel,
    wrappers_1.FormlyWrapperDescription,
    wrappers_1.FormlyWrapperValidationMessages,
    wrappers_1.FormlyWrapperFieldset,
    addons_1.FormlyWrapperAddons,
];
exports.BOOTSTRAP_FORMLY_CONFIG = {
    types: [
        {
            name: 'input',
            component: types_1.FormlyFieldInput,
            wrappers: ['fieldset', 'label'],
        },
        {
            name: 'checkbox',
            component: types_1.FormlyFieldCheckbox,
            wrappers: ['fieldset'],
        },
        {
            name: 'radio',
            component: types_1.FormlyFieldRadio,
            wrappers: ['fieldset', 'label'],
        },
        {
            name: 'select',
            component: types_1.FormlyFieldSelect,
            wrappers: ['fieldset', 'label'],
        },
        {
            name: 'textarea',
            component: types_1.FormlyFieldTextArea,
            wrappers: ['fieldset', 'label'],
        },
        {
            name: 'multicheckbox',
            component: types_1.FormlyFieldMultiCheckbox,
            wrappers: ['fieldset', 'label'],
        },
    ],
    wrappers: [
        { name: 'label', component: wrappers_1.FormlyWrapperLabel },
        { name: 'description', component: wrappers_1.FormlyWrapperDescription },
        { name: 'validation-message', component: wrappers_1.FormlyWrapperValidationMessages },
        { name: 'fieldset', component: wrappers_1.FormlyWrapperFieldset },
        { name: 'addons', component: addons_1.FormlyWrapperAddons },
    ],
    manipulators: [
        { class: description_1.TemplateDescription, method: 'run' },
        { class: validation_1.TemplateValidation, method: 'run' },
        { class: addon_1.TemplateAddons, method: 'run' },
    ],
};


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var common_1 = __webpack_require__(18);
var forms_1 = __webpack_require__(3);
var core_2 = __webpack_require__(2);
var ui_bootstrap_config_1 = __webpack_require__(32);
var formly_validation_message_1 = __webpack_require__(15);
var FormlyBootstrapModule = (function () {
    function FormlyBootstrapModule() {
    }
    return FormlyBootstrapModule;
}());
FormlyBootstrapModule = tslib_1.__decorate([
    core_1.NgModule({
        declarations: ui_bootstrap_config_1.FIELD_TYPE_COMPONENTS.concat([formly_validation_message_1.FormlyValidationMessage]),
        imports: [
            common_1.CommonModule,
            forms_1.ReactiveFormsModule,
            core_2.FormlyModule.forRoot(ui_bootstrap_config_1.BOOTSTRAP_FORMLY_CONFIG),
        ],
    })
], FormlyBootstrapModule);
exports.FormlyBootstrapModule = FormlyBootstrapModule;


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyWrapperAddons = (function (_super) {
    tslib_1.__extends(FormlyWrapperAddons, _super);
    function FormlyWrapperAddons() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FormlyWrapperAddons.prototype.addonRightClick = function ($event) {
        if (this.to['addonRight'].onClick) {
            this.to['addonRight'].onClick(this.to, this, $event);
        }
    };
    FormlyWrapperAddons.prototype.addonLeftClick = function ($event) {
        if (this.to['addonLeft'].onClick) {
            this.to['addonLeft'].onClick(this.to, this, $event);
        }
    };
    return FormlyWrapperAddons;
}(core_2.FieldWrapper));
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyWrapperAddons.prototype, "fieldComponent", void 0);
FormlyWrapperAddons = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-wrapper-addons',
        template: "\n    <div class=\"input-group\">\n    <div class=\"input-group-addon\"\n         *ngIf=\"to.addonLeft\"\n         [ngStyle]=\"{cursor: to.addonLeft.onClick ? 'pointer' : 'inherit'}\"\n         (click)=\"addonLeftClick($event)\">\n        <i [ngClass]=\"to.addonLeft.class\" *ngIf=\"to.addonLeft.class\"></i>\n        <span *ngIf=\"to.addonLeft.text\">{{to.addonLeft.text}}</span>\n    </div>\n    <ng-container #fieldComponent></ng-container>\n    <div class=\"input-group-addon\"\n         *ngIf=\"to.addonRight\"\n         [ngStyle]=\"{cursor: to.addonRight.onClick ? 'pointer' : 'inherit'}\"\n         (click)=\"addonRightClick($event)\">\n        <i [ngClass]=\"to.addonRight.class\" *ngIf=\"to.addonRight.class\"></i>\n        <span *ngIf=\"to.addonRight.text\">{{to.addonRight.text}}</span>\n    </div>\n</div>\n  ",
    })
], FormlyWrapperAddons);
exports.FormlyWrapperAddons = FormlyWrapperAddons;


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyWrapperDescription = (function (_super) {
    tslib_1.__extends(FormlyWrapperDescription, _super);
    function FormlyWrapperDescription() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormlyWrapperDescription;
}(core_2.FieldWrapper));
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyWrapperDescription.prototype, "fieldComponent", void 0);
FormlyWrapperDescription = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-wrapper-description',
        template: "\n    <ng-container #fieldComponent></ng-container>\n    <div>\n      <small class=\"text-muted\">{{to.description}}</small>\n    </div>\n  ",
    })
], FormlyWrapperDescription);
exports.FormlyWrapperDescription = FormlyWrapperDescription;


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyWrapperFieldset = (function (_super) {
    tslib_1.__extends(FormlyWrapperFieldset, _super);
    function FormlyWrapperFieldset() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormlyWrapperFieldset;
}(core_2.FieldWrapper));
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyWrapperFieldset.prototype, "fieldComponent", void 0);
FormlyWrapperFieldset = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-wrapper-fieldset',
        template: "\n    <div class=\"form-group\" [ngClass]=\"{'has-danger': valid}\">\n      <ng-container #fieldComponent></ng-container>\n    </div>\n  ",
    })
], FormlyWrapperFieldset);
exports.FormlyWrapperFieldset = FormlyWrapperFieldset;


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyWrapperLabel = (function (_super) {
    tslib_1.__extends(FormlyWrapperLabel, _super);
    function FormlyWrapperLabel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormlyWrapperLabel;
}(core_2.FieldWrapper));
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyWrapperLabel.prototype, "fieldComponent", void 0);
FormlyWrapperLabel = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-wrapper-label',
        template: "\n    <label [attr.for]=\"id\" class=\"form-control-label\">{{to.label}}</label>\n    <ng-container #fieldComponent></ng-container>\n  ",
    })
], FormlyWrapperLabel);
exports.FormlyWrapperLabel = FormlyWrapperLabel;


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(0);
var core_1 = __webpack_require__(1);
var core_2 = __webpack_require__(2);
var FormlyWrapperValidationMessages = (function (_super) {
    tslib_1.__extends(FormlyWrapperValidationMessages, _super);
    function FormlyWrapperValidationMessages() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FormlyWrapperValidationMessages.prototype, "validationId", {
        get: function () {
            return this.field.id + '-message';
        },
        enumerable: true,
        configurable: true
    });
    return FormlyWrapperValidationMessages;
}(core_2.FieldWrapper));
tslib_1.__decorate([
    core_1.ViewChild('fieldComponent', { read: core_1.ViewContainerRef }),
    tslib_1.__metadata("design:type", core_1.ViewContainerRef)
], FormlyWrapperValidationMessages.prototype, "fieldComponent", void 0);
FormlyWrapperValidationMessages = tslib_1.__decorate([
    core_1.Component({
        selector: 'formly-wrapper-validation-messages',
        template: "\n    <ng-container #fieldComponent></ng-container>\n    <div>\n      <small class=\"text-muted text-danger\" *ngIf=\"valid\" role=\"alert\" [id]=\"validationId\"><formly-validation-message [fieldForm]=\"formControl\" [field]=\"field\"></formly-validation-message></small>\n    </div>\n  ",
    })
], FormlyWrapperValidationMessages);
exports.FormlyWrapperValidationMessages = FormlyWrapperValidationMessages;


/***/ }),
/* 39 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_39__;

/***/ }),
/* 40 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_40__;

/***/ }),
/* 41 */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_41__;

/***/ })
/******/ ]);
});
//# sourceMappingURL=ng-formly.umd.js.map