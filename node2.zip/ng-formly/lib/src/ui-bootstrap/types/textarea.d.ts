import { FieldType } from '../../core';
export declare class FormlyFieldTextArea extends FieldType {
}
