import { AbstractControl } from '@angular/forms';
import { FieldType, FormlyFieldConfig } from '../../core';
export declare class FormlyFieldMultiCheckbox extends FieldType {
    static createControl(model: any, field: FormlyFieldConfig): AbstractControl;
}
