import { FieldType } from '../../core';
export declare class SelectOption {
    label: string;
    value?: string;
    group?: SelectOption[];
    disabled?: boolean;
    constructor(label: string, value?: string, children?: SelectOption[]);
}
export declare class FormlyFieldSelect extends FieldType {
    readonly labelProp: string;
    readonly valueProp: string;
    readonly groupProp: string;
    readonly selectOptions: SelectOption[];
}
