import { FieldType } from '../../core';
export declare class FormlyFieldRadio extends FieldType {
}
