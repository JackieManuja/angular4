import { FieldType } from '../../core';
export declare class FormlyFieldInput extends FieldType {
    readonly type: string;
}
