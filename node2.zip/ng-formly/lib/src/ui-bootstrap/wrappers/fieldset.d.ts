import { ViewContainerRef } from '@angular/core';
import { FieldWrapper } from '../../core';
export declare class FormlyWrapperFieldset extends FieldWrapper {
    fieldComponent: ViewContainerRef;
}
