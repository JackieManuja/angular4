import { ViewContainerRef } from '@angular/core';
import { FieldWrapper } from '../../core';
export declare class FormlyWrapperDescription extends FieldWrapper {
    fieldComponent: ViewContainerRef;
}
