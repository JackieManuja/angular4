import { ViewContainerRef } from '@angular/core';
import { FieldWrapper } from '../../core';
export declare class FormlyWrapperValidationMessages extends FieldWrapper {
    fieldComponent: ViewContainerRef;
    readonly validationId: string;
}
