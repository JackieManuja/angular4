import { ViewContainerRef } from '@angular/core';
import { FieldWrapper } from '../../core';
export declare class FormlyWrapperAddons extends FieldWrapper {
    fieldComponent: ViewContainerRef;
    addonRightClick($event: any): void;
    addonLeftClick($event: any): void;
}
