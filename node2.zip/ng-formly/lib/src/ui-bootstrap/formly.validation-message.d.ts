import { FormControl } from '@angular/forms';
import { FormlyFieldConfig, FormlyValidationMessages } from '../core';
export declare class FormlyValidationMessage {
    private formlyMessages;
    fieldForm: FormControl;
    field: FormlyFieldConfig;
    constructor(formlyMessages: FormlyValidationMessages);
    readonly errorMessage: any;
}
