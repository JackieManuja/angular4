import { FormlyConfig } from '../../core';
export declare class TemplateAddons {
    run(fc: FormlyConfig): void;
}
