import { FormlyConfig } from '../../core';
export declare class TemplateValidation {
    run(fc: FormlyConfig): void;
}
