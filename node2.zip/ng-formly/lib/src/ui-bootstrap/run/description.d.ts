import { FormlyConfig } from '../../core';
export declare class TemplateDescription {
    run(fc: FormlyConfig): void;
}
