import { ConfigOption } from '../core/services/formly.config';
import { FormlyFieldRadio } from './types/types';
import { FormlyWrapperFieldset } from './wrappers/wrappers';
export declare const FIELD_TYPE_COMPONENTS: (typeof FormlyFieldRadio | typeof FormlyWrapperFieldset)[];
export declare const BOOTSTRAP_FORMLY_CONFIG: ConfigOption;
