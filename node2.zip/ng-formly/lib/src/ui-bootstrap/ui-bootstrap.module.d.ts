export declare class FormlyBootstrapModule {
}
