import { ViewContainerRef } from '@angular/core';
import { Field } from './field';
export declare abstract class FieldWrapper extends Field {
    fieldComponent: ViewContainerRef;
}
