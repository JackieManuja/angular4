import { FormGroup, AbstractControl } from '@angular/forms';
import { FormlyTemplateOptions, FormlyFieldConfig } from '../components/formly.field.config';
export declare abstract class Field {
    form: FormGroup;
    field: FormlyFieldConfig;
    model: any;
    options: any;
    readonly key: string;
    readonly formControl: AbstractControl;
    readonly templateOptions: FormlyTemplateOptions;
    readonly to: FormlyTemplateOptions;
    readonly valid: boolean;
    readonly id: string;
    readonly formState: any;
}
