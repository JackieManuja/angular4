import { FormGroup } from '@angular/forms';
import { FormlyConfig } from './formly.config';
import { FormlyFieldConfig } from '../components/formly.field.config';
export declare class FormlyFormBuilder {
    private formlyConfig;
    private defaultPath;
    private validationOpts;
    private formId;
    constructor(formlyConfig: FormlyConfig);
    buildForm(form: FormGroup, fields: FormlyFieldConfig[], model: any, options: any): void;
    private registerFormControls(form, fields, model, options);
    private initFieldExpression(field, model, options);
    private initFieldTemplateOptions(field);
    private initFieldAsyncValidation(field);
    private initFieldValidation(field);
    private addFormControl(form, field, model);
    private getValidation(opt, value);
    private checkMinMax(opt, changes, value);
    private addControl(form, key, formControl, field);
}
