import { Subject } from 'rxjs/Subject';
export declare class FormlyValueChangeEvent {
    key: string;
    value: any;
    constructor(key: string, value: any);
}
export declare class FormlyEventEmitter extends Subject<String> {
    emit(value: any): void;
}
export declare class FormlyPubSub {
    emitters: {};
    setEmitter(key: any, emitter: any): void;
    getEmitter(key: any): any;
    removeEmitter(key: any): void;
}
