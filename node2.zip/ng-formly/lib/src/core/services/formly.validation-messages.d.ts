export declare class FormlyValidationMessages {
    messages: {};
    constructor(configs?: any[]);
    addStringMessage(validator: any, message: any): void;
    getMessages(): {};
    getValidatorErrorMessage(prop: any): any;
}
