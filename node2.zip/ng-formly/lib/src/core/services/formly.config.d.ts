import { OpaqueToken } from '@angular/core';
import { Field } from './../templates/field';
import { FormlyFieldConfig } from '../components/formly.field.config';
export declare const FORMLY_CONFIG_TOKEN: OpaqueToken;
export declare class FormlyConfig {
    types: {
        [name: string]: TypeOption;
    };
    validators: {
        [name: string]: ValidatorOption;
    };
    wrappers: {
        [name: string]: WrapperOption;
    };
    templateManipulators: {
        preWrapper: any[];
        postWrapper: any[];
    };
    extras: {
        fieldTransform: any;
        showError: (field: Field) => boolean;
    };
    constructor(configs?: ConfigOption[]);
    addConfig(config: ConfigOption): void;
    setType(options: TypeOption | TypeOption[]): void;
    getType(name: string): TypeOption;
    getMergedField(field?: FormlyFieldConfig): any;
    setWrapper(options: WrapperOption): void;
    getWrapper(name: string): WrapperOption;
    setTypeWrapper(type: any, name: any): void;
    setValidator(options: ValidatorOption): void;
    getValidator(name: string): ValidatorOption;
    setManipulator(manipulator: any): void;
}
export interface TypeOption {
    name: string;
    component?: any;
    wrappers?: string[];
    extends?: string;
    defaultOptions?: any;
}
export interface WrapperOption {
    name: string;
    component: any;
    types?: string[];
}
export interface ValidatorOption {
    name: string;
    validation: any;
}
export interface ValidationMessageOption {
    name: string;
    message: any;
}
export interface ManipulatorsOption {
    class?: Function;
    method?: string;
}
export interface ConfigOption {
    types?: TypeOption[];
    wrappers?: WrapperOption[];
    validators?: ValidatorOption[];
    validationMessages?: ValidationMessageOption[];
    manipulators?: ManipulatorsOption[];
    extras?: {
        fieldTransform?: any;
        showError?: (field: Field) => boolean;
    };
}
