import { ElementRef, Renderer, OnChanges, SimpleChanges } from '@angular/core';
import { FormlyFieldConfig } from './formly.field.config';
export declare class FormlyAttributes implements OnChanges {
    private renderer;
    private elementRef;
    field: FormlyFieldConfig;
    formControl: any;
    private attributes;
    private statements;
    onFocus(): void;
    onBlur(): void;
    constructor(renderer: Renderer, elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    private getPropValue(field, prop);
    private getStatementValue(statement);
    private canApplyRender(fieldChange, prop);
}
