import { OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyValueChangeEvent } from './../services/formly.event.emitter';
import { FormlyFieldConfig } from './formly.field.config';
import { FormlyFormBuilder } from '../services/formly.form.builder';
export declare class FormlyForm implements OnChanges {
    private formlyBuilder;
    model: any;
    form: FormGroup;
    fields: FormlyFieldConfig[];
    options: any;
    buildForm: boolean;
    private initialModel;
    constructor(formlyBuilder: FormlyFormBuilder);
    ngOnChanges(changes: SimpleChanges): void;
    fieldModel(field: FormlyFieldConfig): any;
    changeModel(event: FormlyValueChangeEvent): void;
    setOptions(): void;
    private resetModel(model?);
    private resetFormModel(model, formModel, path?);
    private resetFormGroup(model, form, actualKey?);
    private resetFormArray(model, formArray, key);
    private updateInitialValue();
}
