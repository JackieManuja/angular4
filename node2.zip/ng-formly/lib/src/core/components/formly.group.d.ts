import { AbstractControl } from '@angular/forms';
import { FieldType } from '../templates/field.type';
export declare class FormlyGroup extends FieldType {
    readonly newOptions: any;
    readonly formlyGroup: AbstractControl;
}
