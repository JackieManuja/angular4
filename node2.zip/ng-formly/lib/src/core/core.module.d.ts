import { ModuleWithProviders } from '@angular/core';
import { ConfigOption } from './services/formly.config';
export declare class FormlyModule {
    static forRoot(config?: ConfigOption): ModuleWithProviders;
    static forChild(config?: ConfigOption): ModuleWithProviders;
}
