import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormlyFieldConfig } from 'ng-formly';


@Component({
  selector: 'app-formly',
  templateUrl: './formly.html',
})

export class FormlyComponent {
form: FormGroup;
  author;
  env;
  _user;
  user: any = {};
  private userFields: Array<FormlyFieldConfig> = [];
  options = {};

  constructor(fb: FormBuilder) {
    this.form = fb.group({});

    this.author = {
      name: '',
      url: ''
    };
    this.env = {
      angularVersion: '2.2.1',
      formlyVersion: '2.0.0-beta.13'
    };

      this.userFields = [
      {
        key: 'text',
        type: 'input',
        templateOptions: {
          label: 'Some awesome text',
          placeholder: 'Some sweet text',
          required: true
        }
      },
      {
        key: 'candy',
        type: 'select',
        templateOptions: {
          label: 'Multiple Options',
          options: [
            {label: 'Snickers', value: 'snickers'},
            {label: 'Baby Ruth', value: 'baby_ruth'},
            {label: 'Milky Way', value: 'milky_way'}
          ]
        }
      }
    ];

      this.user = {
        
      };
  }

  console(data) {
    console.log(data);
  }

  showEmail() {
    this.form.get('email').setValue('mohammedzamakhan');
    this.form.get('checked').setValue(!this.user.checked);
  }

  hide() {
    this.userFields[1].fieldGroup[0].hideExpression = !this.userFields[1].fieldGroup[0].hideExpression;
  }

  changeEmail(value) {
    this.form.get('email').setValue(value);
  }

  resetForm() {
    this.form.reset({
      email: 'email@gmail.com',
      checked: true,
      select: 'male',
      title: 'mr',
      toggleVal: true,
      interest: {
        movies: false,
        sports: false,
        others: true
      }
    });
  }

  submit(user) {
    console.log(user);
  }
}